﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using BAL;
using ExceptionTMS;
using Entities;
using System.Data;

namespace UI
{
    /// <summary>
    /// Interaction logic for AdminMeny.xaml
    /// </summary>
    public partial class AdminMeny : Window
    {
        public AdminMeny()
        {
            InitializeComponent();
        }

        private void btn_RegisterNewUser_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mw = new MainWindow();
            mw.Show();
            this.Hide();
        }

        private void btn_ShowAllTravel_Click(object sender, RoutedEventArgs e)
        {
            DataTable dt = BAL.BAL_Travel.ShowAlltravelDetails();
            DataGrid1.ItemsSource = dt.DefaultView;
        }

        private void btn_AdminSignOut_Click(object sender, RoutedEventArgs e)
        {
            UserLogin ul = new UserLogin();
            ul.Show();
            this.Hide();
        }

        private void btn_ShowExpenseRequests_Click(object sender, RoutedEventArgs e)
        {
            DataTable dt = BAL.BAL_Travel.ShowAllExpenseDetails();
            DataGrid1.ItemsSource = dt.DefaultView;
        }

        private void SearchMR_Click(object sender, RoutedEventArgs e)
        {
            int intParsedValue;
            if (!int.TryParse(txtSearchByMrNo.Text, out intParsedValue))
            {
                MessageBox.Show("MR_No can't be Empty and should only contain numbers!");
            }
            else
            {
                DataTable dt = BAL.BAL_Travel.SearchByMrNo(Convert.ToInt32(txtSearchByMrNo.Text));
                if (dt.Rows.Count>0)
                    DataGrid1.ItemsSource = dt.DefaultView;

                else
                    MessageBox.Show("Sorry No Such Record exists!");

            }
            
        }
       

        private void txtSearchByMrNo_GotFocus(object sender, RoutedEventArgs e)
        {
            txtSearchByMrNo.Text = "";
        }

        private void txtSearchByEmpId_GotFocus(object sender, RoutedEventArgs e)
        {
            txtSearchByEmpId.Text = "";
        }

        private void SearchByEID_Click(object sender, RoutedEventArgs e)
        {
            int intParsedValue;
            if (!int.TryParse(txtSearchByEmpId.Text, out intParsedValue))
            {
                MessageBox.Show("Employee ID  can't be Empty and should only contain numbers!");
            }
            else
            {
                DataTable dt = BAL.BAL_Travel.SearchByEmpId(int.Parse(txtSearchByEmpId.Text));
                if (dt.Rows.Count>0)
                    DataGrid1.ItemsSource = dt.DefaultView;

                else
                    MessageBox.Show("Sorry No Such Record exists!");
            }
            
        }

        




    }
}
