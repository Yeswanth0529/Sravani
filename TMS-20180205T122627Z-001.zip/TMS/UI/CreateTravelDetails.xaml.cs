﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Entities;
using BAL;
using System.Data.SqlClient;

namespace UI
{
    /// <summary>
    /// Interaction logic for CreateTravelDetails.xaml
    /// </summary>
    public partial class CreateTravelDetails : Window
    {
        public CreateTravelDetails()
        {
            InitializeComponent();
            txtId.Text = UserLogin.id.ToString();
            string cs = @"Data Source= RAJAT-PC\RAJAT; Initial Catalog= TravelMngmt; Integrated Security=true";
            string q = "select nextID=max(MR_No)+1 from Travel_Details";
            SqlConnection con = new SqlConnection(cs);
            SqlCommand cmd = new SqlCommand(q, con);
            con.Open();
            int r = Convert.ToInt32(cmd.ExecuteScalar());
            con.Close();
            txtMR_No.Text = r.ToString(); 
        }

        private void btn_create_travelDetails_Click(object sender, RoutedEventArgs e)
        {
            try
            {


                TravelDetails obj = new TravelDetails();
                obj.ID = int.Parse(txtId.Text);
                obj.MR_No = int.Parse(txtMR_No.Text);
                obj.Reason_for_Travel = txtReason.Text;
                obj.Journey_From = txtJourneyFrom.Text;
                obj.Journey_To = txtJourneyTo.Text;
                DateTime parsedValue;
                if (!DateTime.TryParse(txtTravelDate.Text, out parsedValue))
                {
                    MessageBox.Show("Travel Date/Return must be in correct Format (YYYY/MM/DD)");
                }
                else
                {
                    obj.Travel_Date = DateTime.Parse(txtTravelDate.Text);
                }

                if (!DateTime.TryParse(txtReturnDate.Text, out parsedValue))
                {
                    MessageBox.Show("Travel Date/Return must be in correct Format (YYYY/MM/DD)");
                }
                else
                {
                    obj.Return_Date = DateTime.Parse(txtReturnDate.Text);
                }

                TimeSpan a = obj.Return_Date - obj.Travel_Date;
                obj.Duration = a.Days;

                if (BAL.BAL_Travel.Create_Travel_Details(obj))
                {
                    MessageBox.Show("Succesfully created!");
                    MessageBox.Show("Please note down your auto generated MR_No - " + txtMR_No.Text);

                }
                else
                {
                    MessageBox.Show("Could not be Created !");
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btn_Back_Click(object sender, RoutedEventArgs e)
        {
            UserMenu um = new UserMenu();
            um.Show();
            this.Hide();
        }
    }
}
