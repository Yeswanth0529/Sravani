﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using BAL;
using Entities;
using System.Data.SqlClient;
using System.Data;

namespace UI
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            string cs = @"Data Source= RAJAT-PC\RAJAT; Initial Catalog= TravelMngmt; Integrated Security=true";
            string q = "select nextID=max(ID)+1 from Employee";
            SqlConnection con = new SqlConnection(cs);
            SqlCommand cmd = new SqlCommand(q, con);
            con.Open();
            int r =Convert.ToInt32(cmd.ExecuteScalar());
            con.Close();
            txtID.Text = r.ToString(); 
            //cmd.CommandType = CommandType.StoredProcedure;
            //cmd.CommandText = "Test";
            //cmd.Parameters.Add("@i",SqlDbType.Int);
            //cmd.Parameters["@i"].Direction = ParameterDirection.Output;
            //con.Open();
            //cmd.ExecuteNonQuery();
            //con.Close();
            //txtID.Text = cmd.Parameters["@i"].Value.ToString();



        }

        private void btn_Register_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Employee obj = new Employee();
                obj.FName = txtFname.Text;
                obj.LName = txtLname.Text;
                int parsedValue;
                if (!int.TryParse(txtID.Text, out parsedValue))
                {
                    MessageBox.Show("ID can only contain numbers!");
                }
                else
                {
                    obj.ID = int.Parse(txtID.Text);
                }
                obj.Location = txtLoc.Text;
                obj.Password = txtPass.Text;
                obj.Account_Number = txtAccNo.Text;
                obj.Designation = CmbBoxDesig.Text;

                if (BAL.BAL_Travel.Register_New_Employee(obj))
                {
                    MessageBox.Show("Succesfully Registered!");
                }
                else
                {
                    MessageBox.Show("Unable to Register!");
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }
    }
}
