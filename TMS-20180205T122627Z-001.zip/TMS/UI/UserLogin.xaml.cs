﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using BAL;

namespace UI
{
    /// <summary>
    /// Interaction logic for UserLogin.xaml
    /// </summary>
    public partial class UserLogin : Window
    {
        public static int id;
        public UserLogin()
        {
            InitializeComponent();
        }

        private void btn_Login_Click(object sender, RoutedEventArgs e)
        {
            if (BAL.BAL_Travel.User_Login(int.Parse(txtEmpId.Text), txtPassword.Text))
            {
                id = int.Parse(txtEmpId.Text);
                MessageBox.Show("Login Succesful!");
                UserMenu um = new UserMenu();
                um.Show();
                this.Hide();
                
            }
            else
                MessageBox.Show("Invalid Username/Password");
        }

        private void btn_AdminLinkFrmUser_Click(object sender, RoutedEventArgs e)
        {
            AdminLogin amu = new AdminLogin();
            amu.Show();
            this.Hide();

        }
    }
}
