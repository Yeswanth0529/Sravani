﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using BAL;
using ExceptionTMS;
using Entities;

namespace UI
{
    /// <summary>
    /// Interaction logic for AdminLogin.xaml
    /// </summary>
    public partial class AdminLogin : Window
    {
        public AdminLogin()
        {
            InitializeComponent();
        }

        private void btn_loginAdmin_Click(object sender, RoutedEventArgs e)
        {
            if(BAL.BAL_Travel.Admin_Login(txtAdminUsername.Text,AdminPassword.Password.ToString()))
            {
                MessageBox.Show("Login Succesful!");
                AdminMeny am = new AdminMeny();
                am.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Incorrect Credentials !");
            }
        }
    }
}
