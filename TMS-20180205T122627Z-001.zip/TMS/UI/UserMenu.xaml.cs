﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using BAL;
using Entities;

namespace UI
{
    /// <summary>
    /// Interaction logic for UserMenu.xaml
    /// </summary>
    public partial class UserMenu : Window
    {
        public static bool check = true;
        public UserMenu()
        {
            InitializeComponent();
            if (!BAL.BAL_Travel.ifTravlled(UserLogin.id))
            {
                check = false;
            }
            if(!check)
            {
                btn_ExpenseCreate.IsEnabled = false;
            }
            else
            {
                btn_ExpenseCreate.IsEnabled = true;
            }

        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            UpdateUserDetails ud = new UpdateUserDetails();
            ud.Show();
            this.Hide();
        }

        private void btn_CreateTravelDetails_Click(object sender, RoutedEventArgs e)
        {
            CreateTravelDetails cd = new CreateTravelDetails();
            cd.Show();
            this.Hide();
        }

        private void btn_ExpenseCreate_Click(object sender, RoutedEventArgs e)
        {
            CreateExpense ce = new CreateExpense();
            ce.Show();
            this.Hide();
        }

        private void btn_SearchExpense_Click(object sender, RoutedEventArgs e)
        {
            datagrid_1.ItemsSource = BAL.BAL_Travel.ShowExpenseDetails(UserLogin.id).DefaultView;
        }

        private void btn_SearchTravel_Click(object sender, RoutedEventArgs e)
        {
            datagrid_1.ItemsSource = BAL.BAL_Travel.ShowtravelDetails(UserLogin.id).DefaultView;
        }

        private void btn_UserSignOut_Click(object sender, RoutedEventArgs e)
        {
            UserLogin ul = new UserLogin();
            ul.Show();
            this.Hide();
        }
    }
}
