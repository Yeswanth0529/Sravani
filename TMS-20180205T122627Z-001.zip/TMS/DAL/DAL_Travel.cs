﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entities;
using System.Data.SqlClient;
using System.Data;
using ExceptionTMS;

namespace DAL
{
    public class DAL_Travel
    {
        public static bool Register_new_Employee(Employee obj)
        {
            bool flag = false;
            string cs = @"Data Source= RAJAT-PC\RAJAT; Initial Catalog= TravelMngmt; Integrated Security=true";
            string q = "insert into Employee values(@id,@fname,@lname,@loc,@acc,@pass,@desig)";
            SqlConnection con = new SqlConnection(cs);
            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand(q, con);
                cmd.Parameters.Add(new SqlParameter("@id", obj.ID));
                cmd.Parameters.Add(new SqlParameter("@fname", obj.FName));
                cmd.Parameters.Add(new SqlParameter("@lname", obj.LName));
                cmd.Parameters.Add(new SqlParameter("@loc", obj.Location));
                cmd.Parameters.Add(new SqlParameter("@acc", obj.Account_Number));
                cmd.Parameters.Add(new SqlParameter("@pass", obj.Password));
                cmd.Parameters.Add(new SqlParameter("@desig", obj.Designation));
                if (cmd.ExecuteNonQuery() > 0)
                    flag = true;

                return flag;
            }
            catch (SqlException)
            {
                return flag;
            }
            finally
            {
                con.Close();

            }
        }

        public static bool UserLoginClick(int id, string password)
        {
            bool flag = false;
            string cs = @"Data Source= RAJAT-PC\RAJAT; Initial Catalog= TravelMngmt; Integrated Security=true";
            string q = "select * from Employee";
            SqlConnection con = new SqlConnection(cs);

            SqlCommand cmd = new SqlCommand(q, con);

            con.Open();
            try
            {
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        string user = dr[0].ToString();
                        string pass = dr[5].ToString();
                        if (user == id.ToString() && pass == password)
                        {
                            flag = true;
                        }
                    }
                }
                    return flag;

            }
            catch (SqlException)
            {
                return flag;
            }
            finally
            {
                con.Close();
            }
        }

        public static bool Update_User_Details(string fname, string Lname, string AccNo, string Pass, int id)
        {
            bool flag = false;

            string cs = @"Data Source= RAJAT-PC\RAJAT; Initial Catalog= TravelMngmt; Integrated Security=true";
            string q = "update Employee set First_Name=@f,Last_Name=@l,Account_Number=@acc,Pass=@p where id=@i";
            SqlConnection con = new SqlConnection(cs);
            SqlCommand cmd = new SqlCommand(q, con);
            try
            {
                con.Open();
                cmd.Parameters.Add(new SqlParameter("@f", fname));
                cmd.Parameters.Add(new SqlParameter("@l", Lname));
                cmd.Parameters.Add(new SqlParameter("@acc", AccNo));
                cmd.Parameters.Add(new SqlParameter("@p", Pass));
                cmd.Parameters.Add(new SqlParameter("@i", id));
                if (cmd.ExecuteNonQuery() > 0)
                {
                    flag = true;
                }
                return flag;
            }
            catch (SqlException)
            {
                return flag;
            }
            finally
            {
                con.Close();
            }

        }

        public static bool Create_Travel_Details(TravelDetails obj)
        {
            bool flag = false;
            string cs = @"Data Source= RAJAT-PC\RAJAT; Initial Catalog= TravelMngmt; Integrated Security=true";
            string q = "insert into Travel_Details values (@mr,@id,@jf,@jt,@Reason,@td,@rd,@duration)";
            SqlConnection con = new SqlConnection(cs);
            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand(q, con);
                cmd.Parameters.Add(new SqlParameter("@mr", obj.MR_No));
                cmd.Parameters.Add(new SqlParameter("@id", obj.ID));
                cmd.Parameters.Add(new SqlParameter("@jf", obj.Journey_From));
                cmd.Parameters.Add(new SqlParameter("@jt", obj.Journey_To));
                cmd.Parameters.Add(new SqlParameter("@Reason", obj.Reason_for_Travel));
                cmd.Parameters.Add(new SqlParameter("@td", obj.Travel_Date));
                cmd.Parameters.Add(new SqlParameter("@rd", obj.Return_Date));
                cmd.Parameters.Add(new SqlParameter("@duration", obj.Duration));
                if (cmd.ExecuteNonQuery() > 0)
                {
                    flag = true;
                }
                return flag;
            }
            catch (SqlException)
            {
                return flag;
            }
            finally
            {
                con.Close();
            }
        }
        public static bool CreateExpenseDetails(ExpenseDetails obj)
        {
            bool result = false;

            string cs = @"Data Source= RAJAT-PC\RAJAT; Initial Catalog= travelMngmt; Integrated Security=true";
            string q = "insert into expense_details values (@rid,@type,@date,@Amount,@PaymentType,@mr,@accn,@status,@id)";
            SqlConnection con = new SqlConnection(cs);
            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand(q, con);
                cmd.Parameters.Add(new SqlParameter("@rid", obj.Expense_Report_Id));
                cmd.Parameters.Add(new SqlParameter("@mr", obj.MR_No));
                cmd.Parameters.Add(new SqlParameter("@date", obj.Expense_Date));
                cmd.Parameters.Add(new SqlParameter("@Amount", obj.Amount));
                cmd.Parameters.Add(new SqlParameter("@PaymentType", obj.Payment_Type));
                cmd.Parameters.Add(new SqlParameter("@accn", obj.Account_Number));
                cmd.Parameters.Add(new SqlParameter("@type", obj.Expense_Type));
                cmd.Parameters.Add(new SqlParameter("@status", obj.Expense_Status));
                cmd.Parameters.Add(new SqlParameter("@id", obj.ID));

                if (cmd.ExecuteNonQuery() > 0)
                {
                    result = true;
                }

                return result;
            }


            catch (SqlException)
            {
                return result;
            }
            finally
            {
                con.Close();

            }
        }

        public static DataTable ShowExpenseDetails(int id)
        {
            string cs = @"Data Source= RAJAT-PC\RAJAT; Initial Catalog= TravelMngmt; Integrated Security=true";
            string q = "select * from expense_details where ID=@i";
            SqlConnection con = new SqlConnection(cs);
            SqlCommand cmd = new SqlCommand(q, con);
            cmd.Parameters.Add(new SqlParameter("@i", id));
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable("Employee");
            try
            {
               
                sda.Fill(dt);
                return dt;

            }
            catch (SqlException se)
            {
                return dt;
                throw se;
            }
        }

        public static DataTable ShowTravelDetails(int id)
        {
            string cs = @"Data Source= RAJAT-PC\RAJAT; Initial Catalog= TravelMngmt; Integrated Security=true";
            string q = "select * from Travel_details where ID=@i";
            SqlConnection con = new SqlConnection(cs);
            SqlCommand cmd = new SqlCommand(q, con);
            cmd.Parameters.Add(new SqlParameter("@i", id));
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable("Employee");
            try
            {

                sda.Fill(dt);
                return dt;

            }
            catch (SqlException se)
            {
                return dt;
                throw se;
            }
        }

        public static bool Check_AccNo(ExpenseDetails obj)
        {
            bool checkAccn = true;
            string cs = @"Data Source= RAJAT-PC\RAJAT; Initial Catalog= TravelMngmt; Integrated Security=true";
            string q1 = "select * from Employee where id=@i";
            

            SqlConnection con = new SqlConnection(cs);
            SqlCommand cmd = new SqlCommand(q1, con);
            cmd.Parameters.Add(new SqlParameter("@i", obj.ID));
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
                
            try
            {
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        if (obj.Account_Number != dr[4].ToString())
                        {
                            checkAccn = false;
                        }
                    }
                }
                con.Close();
                return checkAccn;
            }
            catch( TMSExceptions)
            {
                throw;
            }
            catch(SqlException ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
        }

        public static bool Check_MrNo(ExpenseDetails obj)
        {
            bool checkMrNo = true;
            string cs = @"Data Source= RAJAT-PC\RAJAT; Initial Catalog= TravelMngmt; Integrated Security=true";
            string q1 = "select * from Travel_Details where id=@i";
            SqlConnection con = new SqlConnection(cs);
            SqlCommand cmd = new SqlCommand(q1, con);
            cmd.Parameters.Add(new SqlParameter("@i", obj.ID));
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            try
            {
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        if (obj.MR_No != Convert.ToInt32(dr[0]))
                        {
                            checkMrNo = false;
                        }
                    }
                }
                con.Close();
                return checkMrNo;
            }
            catch (TMSExceptions)
            {
                throw;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
        }

        public static bool Check_ExpenseDate(ExpenseDetails obj)
        {
            bool checkExpDate = true;
            DateTime to;
            DateTime ret;
            string cs = @"Data Source= RAJAT-PC\RAJAT; Initial Catalog= TravelMngmt; Integrated Security=true";
            string q1 = "select * from Travel_Details where Mr_No=@mr";
            SqlConnection con = new SqlConnection(cs);
            SqlCommand cmd = new SqlCommand(q1, con);
            cmd.Parameters.Add(new SqlParameter("@mr", obj.MR_No));
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            try
            {
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        to = Convert.ToDateTime(dr[5]);
                        ret = Convert.ToDateTime(dr[6]);
                        if (obj.Expense_Date>ret || obj.Expense_Date<to)
                        {
                            checkExpDate = false;
                        }
                    }
                }
                con.Close();
                return checkExpDate;
            }
            catch (TMSExceptions)
            {
                throw;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
        }

        public static bool Check_Analyst(ExpenseDetails obj)
        {
            bool checkAnalyst = true;
            string cs = @"Data Source= RAJAT-PC\RAJAT; Initial Catalog= TravelMngmt; Integrated Security=true";
            string q1 = "select Designation from Employee where id=@i";


            SqlConnection con = new SqlConnection(cs);
            SqlCommand cmd = new SqlCommand(q1, con);
            cmd.Parameters.Add(new SqlParameter("@i", obj.ID));
            con.Open();
            string d = Convert.ToString(cmd.ExecuteScalar());
            try
            {
                if(d!="Analyst")
                {
                    checkAnalyst = false;
                }
                    
                    con.Close();
                return checkAnalyst;
            }
            catch (TMSExceptions)
            {
                throw;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
        }

        public static bool Check_SrAnalyst(ExpenseDetails obj)
        {
            bool checkSrAnalyst = true;
            string cs = @"Data Source= RAJAT-PC\RAJAT; Initial Catalog= TravelMngmt; Integrated Security=true";
            string q1 = "select Designation from Employee where id=@i";

            SqlConnection con = new SqlConnection(cs);
            SqlCommand cmd = new SqlCommand(q1, con);
            cmd.Parameters.Add(new SqlParameter("@i", obj.ID));
            con.Open();
            string d = Convert.ToString(cmd.ExecuteScalar());
            try
            {
                if (d != "Senior Analyst")
                {
                    checkSrAnalyst = false;
                }

                con.Close();
                return checkSrAnalyst;
            }
            catch (TMSExceptions)
            {
                throw;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
        }

        public static bool Check_Mgr(ExpenseDetails obj)
        {
            bool checkMgr = true;
            string cs = @"Data Source= RAJAT-PC\RAJAT; Initial Catalog= TravelMngmt; Integrated Security=true";
            string q1 = "select Designation from Employee where id=@i";

            SqlConnection con = new SqlConnection(cs);
            SqlCommand cmd = new SqlCommand(q1, con);
            cmd.Parameters.Add(new SqlParameter("@i", obj.ID));
            con.Open();
            string d = Convert.ToString(cmd.ExecuteScalar());
            try
            {
                if (d != "Manager")
                {
                    checkMgr = false;
                }

                con.Close();
                return checkMgr;
            }
            catch (TMSExceptions)
            {
                throw;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
        }


        public static bool Check_SrMgr(ExpenseDetails obj)
        {
            bool checkSrMgr = true;
            string cs = @"Data Source= RAJAT-PC\RAJAT; Initial Catalog= TravelMngmt; Integrated Security=true";
            string q1 = "select Designation from Employee where id=@i";

            SqlConnection con = new SqlConnection(cs);
            SqlCommand cmd = new SqlCommand(q1, con);
            cmd.Parameters.Add(new SqlParameter("@i", obj.ID));
            con.Open();
            string d = Convert.ToString(cmd.ExecuteScalar());
            try
            {
                if (d != "Senior Manager")
                {
                    checkSrMgr = false;
                }

                con.Close();
                return checkSrMgr;
            }
            catch (TMSExceptions)
            {
                throw;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
        }

        public static DataTable ShowAllTravelDetails()
        {
            string cs = @"Data Source= RAJAT-PC\RAJAT; Initial Catalog= TravelMngmt; Integrated Security=true";
            string q = "select * from Travel_details where ID>100";
            SqlConnection con = new SqlConnection(cs);
            SqlCommand cmd = new SqlCommand(q, con);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable("Employee");
            try
            {

                sda.Fill(dt);
                return dt;

            }
            catch (SqlException se)
            {
                return dt;
                throw se;
            }
        }
        public static bool AdminLogin(string id,string password)
        {
            bool login = false;
            string cs = @"Data Source= RAJAT-PC\RAJAT; Initial Catalog= TestDB; Integrated Security=true";
            string q = "select * from Administrator";
            SqlConnection con = new SqlConnection(cs);
            SqlCommand cmd = new SqlCommand(q, con);

            con.Open();
            try
            {
                SqlDataReader dr = cmd.ExecuteReader();
                dr.Read();
                string user = dr[0].ToString();
                string pass = dr[1].ToString();
                if (user == id && pass == password)
                    login = true;

                return login;
            }
            catch(TMSExceptions)
            {
                throw;
            }
            catch (SqlException sx)
            {
                throw sx;
            }
            finally
            {
                con.Close();
            }
        }

        public static DataTable ShowAllExpenseDetails()
        {
            string cs = @"Data Source= RAJAT-PC\RAJAT; Initial Catalog= TravelMngmt; Integrated Security=true";
            string q = "select * from Expense_details";
            SqlConnection con = new SqlConnection(cs);
            SqlCommand cmd = new SqlCommand(q, con);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable("Employee");
            try
            {

                sda.Fill(dt);
                return dt;

            }
            catch (SqlException se)
            {
                return dt;
                throw se;
            }
        }

        public static DataTable SearchByMrNo(int Mr_No)
        {
            string cs = @"Data Source= RAJAT-PC\RAJAT; Initial Catalog= TravelMngmt; Integrated Security=true";
            string q = "select * from Expense_details where MR_No=@mr";
            SqlConnection con = new SqlConnection(cs);
            SqlCommand cmd = new SqlCommand(q, con);
            cmd.Parameters.Add(new SqlParameter("@mr", Mr_No));
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable("Employee");
            try
            {

                sda.Fill(dt);
                return dt;

            }
            catch (SqlException se)
            {
                return dt;
                throw se;
            }
        }
        public static DataTable SearchByEmpID(int EmpId)
        {
            string cs = @"Data Source= RAJAT-PC\RAJAT; Initial Catalog= TravelMngmt; Integrated Security=true";
            string q = "select * from travel_details where Id=@id";
            SqlConnection con = new SqlConnection(cs);
            SqlCommand cmd = new SqlCommand(q, con);
            cmd.Parameters.Add(new SqlParameter("@id", EmpId));
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable("Employee");
            try
            {

                sda.Fill(dt);
                return dt;

            }
            catch (SqlException se)
            {
                return dt;
                throw se;
            }
        }

        public static bool CheckIfTravelled(int EmpId)
        {
            bool travelled = false;
            string cs = @"Data Source= RAJAT-PC\RAJAT; Initial Catalog= TravelMngmt; Integrated Security=true";
            string q = "select MR_No from travel_details where Id=@id";
            SqlConnection con = new SqlConnection(cs);
            SqlCommand cmd = new SqlCommand(q, con);
            cmd.Parameters.Add(new SqlParameter("@id", EmpId));
            con.Open();
            try
            {
                int r = Convert.ToInt32(cmd.ExecuteScalar());
                if (r > 0)
                    travelled = true;

            }
            catch (TMSExceptions)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            finally
            {
                con.Close();
            }
            
            return travelled;
        }
    }
}